Notes:

Prelim.Rmd: The preliminary models (section 1 of the report) is located here. All selected single variable analysis used in the report is locaated here

ModelSelection.Rmd: The file is where we select the initial model through forward, backward, and stepwise selection.

Interaction_and_Higher_Order_Terms.Rmd: Here we analyze the information realated to interaction terms and higher order terms overall

OutliersInfluentialPoints.Rmd: Here we analyze the outliers and influential points related to what we analyzed in the report.

ModelValidation.Rmd: Here we validate the model through F-tests, Confidence Intervals, and Repeated K-Fold Cross Validation